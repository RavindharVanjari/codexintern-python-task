# CodexIntern Python Task Folder

## Includes:
✅ Task 3 Slab 1: Matrix Operations Tool using Flask  
✅ Task 2 Slab 2: Sentiment Analysis using Flask and TextBlob  
✅ Task 3 Slab 2: Speech-to-Image Generation using monsterapi

## Instructions:
1️⃣ Install requirements:
```bash
pip install -r requirements.txt
```
2️⃣ Run:
```bash
python app.py
```
3️⃣ Visit `http://127.0.0.1:5000/` for Sentiment Analysis.  
Visit `http://127.0.0.1:5000/matrix` for Matrix Operations.  
Visit `http://127.0.0.1:5000/speech-to-image` for Speech-to-Image generation (replace API key before using).

Edit `app.py` to insert your `YOUR_MONSTERAPI_KEY` before running the speech-to-image task.