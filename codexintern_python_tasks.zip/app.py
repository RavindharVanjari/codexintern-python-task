import numpy as np
from flask import Flask, render_template, request
from textblob import TextBlob
import speech_recognition as sr
import requests
import json

app = Flask(__name__)

# Task 3 Slab 1 - Matrix Operations Tool
@app.route('/matrix', methods=['GET', 'POST'])
def matrix_operations():
    result = {}
    if request.method == 'POST':
        A = np.array(eval(request.form['matrix_a']))
        B = np.array(eval(request.form['matrix_b']))
        result['add'] = np.array2string(np.add(A, B))
        result['subtract'] = np.array2string(np.subtract(A, B))
        result['multiply'] = np.array2string(np.dot(A, B))
        result['transpose_A'] = np.array2string(np.transpose(A))
        result['transpose_B'] = np.array2string(np.transpose(B))
        result['det_A'] = np.linalg.det(A)
        result['det_B'] = np.linalg.det(B)
    return render_template('matrix.html', result=result)

# Task 2 Slab 2 - Sentiment Analysis
@app.route('/', methods=['GET', 'POST'])
def sentiment_analysis():
    result = {}
    if request.method == 'POST':
        user_text = request.form['text']
        blob = TextBlob(user_text)
        polarity = blob.sentiment.polarity
        subjectivity = blob.sentiment.subjectivity
        if polarity > 0:
            sentiment = "Positive"
        elif polarity < 0:
            sentiment = "Negative"
        else:
            sentiment = "Neutral"
        result = {
            'sentiment': sentiment,
            'polarity': polarity,
            'subjectivity': subjectivity
        }
    return render_template('index.html', result=result)

# Task 3 Slab 2 - Speech to Image Generation using monsterapi
@app.route('/speech-to-image')
def speech_to_image():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        audio = r.listen(source)
    text = r.recognize_google(audio)
    headers = {"Authorization": "Bearer YOUR_MONSTERAPI_KEY"}
    data = {"model": "dalle-3", "prompt": text, "size": "1024x1024"}
    response = requests.post("https://api.monsterapi.ai/v1/generate", headers=headers, json=data)
    image_url = json.loads(response.text)["data"][0]["url"]
    return f"<img src='{image_url}' alt='Generated Image' />"

if __name__ == "__main__":
    app.run(debug=True)