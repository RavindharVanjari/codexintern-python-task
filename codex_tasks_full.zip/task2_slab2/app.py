from flask import Flask, request, render_template_string
from textblob import TextBlob

app = Flask(__name__)

HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head><title>Sentiment Analyzer</title></head>
<body>
  <h2>Sentiment Analysis</h2>
  <form method="POST">
    <textarea name="text" rows="6" cols="50" placeholder="Enter text here..."></textarea><br>
    <input type="submit" value="Analyze">
  </form>
  {% if result %}
    <h3>Results:</h3>
    <p><b>Polarity:</b> {{ result.polarity }}</p>
    <p><b>Subjectivity:</b> {{ result.subjectivity }}</p>
    <p><b>Sentiment:</b> {{ result.sentiment }}</p>
  {% endif %}
</body>
</html>
"""

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    if request.method == "POST":
        text = request.form["text"]
        blob = TextBlob(text)
        sentiment = "Positive" if blob.polarity > 0 else "Negative" if blob.polarity < 0 else "Neutral"
        result = {
            "polarity": blob.polarity,
            "subjectivity": blob.subjectivity,
            "sentiment": sentiment
        }
    return render_template_string(HTML_TEMPLATE, result=result)

if __name__ == "__main__":
    app.run(debug=True)