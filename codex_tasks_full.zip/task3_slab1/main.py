import numpy as np

def get_matrix_input(name):
    rows = int(input(f"Enter the number of rows for {name}: "))
    cols = int(input(f"Enter the number of columns for {name}: "))
    print(f"Enter elements for {name} (row-wise):")
    matrix = []
    for _ in range(rows):
        row = list(map(float, input().split()))
        matrix.append(row)
    return np.array(matrix)

def main():
    print("Matrix Operations Tool")
    A = get_matrix_input("Matrix A")

    print("\nChoose operation:")
    print("1. Addition")
    print("2. Subtraction")
    print("3. Multiplication")
    print("4. Transpose")
    print("5. Determinant")

    choice = input("Enter choice (1-5): ")

    if choice in ['1', '2', '3']:
        B = get_matrix_input("Matrix B")
        if choice == '1':
            result = A + B
        elif choice == '2':
            result = A - B
        else:
            result = np.dot(A, B)
    elif choice == '4':
        result = A.T
    elif choice == '5':
        if A.shape[0] == A.shape[1]:
            result = np.linalg.det(A)
        else:
            result = "Determinant not defined for non-square matrices."
    else:
        result = "Invalid choice"

    print("\nResult:")
    print(result)

if __name__ == "__main__":
    main()